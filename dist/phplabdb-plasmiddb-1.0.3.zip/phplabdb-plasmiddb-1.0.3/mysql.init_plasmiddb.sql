-- phpLabDB PlasmidDB plugin
--
-- Copyright 2004 M.Bekaert
-- http://phplabdb.sourceforge.net
--
-- MySQL database: db_plasmiddb
---------------------------------------------------------

--
-- Database: db_plasmiddb
--

CREATE DATABASE db_plasmiddb;

GRANT ALL ON db_plasmiddb.* TO phplabdb IDENTIFIED BY 'wlclj7rwa77a';

FLUSH PRIVILEGES;
