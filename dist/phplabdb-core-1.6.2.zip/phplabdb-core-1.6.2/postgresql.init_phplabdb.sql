-- phpLabDB core 
--
-- Copyright 2003-2005 M.Bekaert
-- http://phplabdb.sourceforge.net
--
-- PostgreSQL database: db_phplabdb
---------------------------------------------------------

--
-- CREATE USER database
--

CREATE USER apache CREATEDB PASSWORD 'wlclj7rwa77a';

CREATE DATABASE db_phplabdb WITH OWNER apache;

