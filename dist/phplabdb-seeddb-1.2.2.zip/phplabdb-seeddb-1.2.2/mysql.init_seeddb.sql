-- phpLabDB SeedDB plugin
--
-- Copyright 2003-2004 M.Bekaert
-- http://phplabdb.sourceforge.net
--
-- MySQL database: db_seeddb
---------------------------------------------------------

--
-- Database: db_seeddb
--

CREATE DATABASE db_seeddb;

GRANT ALL ON db_seeddb.* TO phplabdb IDENTIFIED BY 'wlclj7rwa77a';

FLUSH PRIVILEGES;
