-- phpLabDB StrainDB plugin
--
-- Copyright 2004 M.Bekaert
-- http://phplabdb.sourceforge.net
--
-- MySQL database: db_straindb
---------------------------------------------------------

--
-- Database: db_straindb
--

CREATE DATABASE db_straindb;

GRANT ALL ON db_straindb.* TO phplabdb IDENTIFIED BY 'wlclj7rwa77a';

FLUSH PRIVILEGES;
