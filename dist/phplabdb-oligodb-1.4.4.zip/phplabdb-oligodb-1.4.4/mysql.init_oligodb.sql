-- phpLabDB OligoDB plugin
--
-- Copyright 2003 M.Bekaert
-- http://phplabdb.sourceforge.net
--
-- MySQL database: db_oligodb
---------------------------------------------------------

--
-- Database: db_oligodb
--

CREATE DATABASE db_oligodb;

GRANT SELECT,INSERT,UPDATE,DELETE,CREATE,DROP,RELOAD ON db_oligodb.* TO phplabdb IDENTIFIED BY 'wlclj7rwa77a';

FLUSH PRIVILEGES;
